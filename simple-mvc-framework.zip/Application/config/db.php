<?php

return [
	"host"=>"localhost",
	"name"=>"das4",
	"user"=>"root",
	"password"=>""
];

?>