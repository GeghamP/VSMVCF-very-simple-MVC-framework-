<h3>Registation page</h3>
<form>
	<p>Login</p>
	<p><input type="text"></p>
	<p>Password</p>
	<p><input type="password"></p>
	<p><button>register</button></p>
</form>