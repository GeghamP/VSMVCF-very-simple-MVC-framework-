<h3>Login page</h3>
<form action="/account/login" method="post">
	<div class="form-group">
		<label>Login</label>
		<input class="form-control" type="text" name="login">
	</div>	
	<div class="form-group">
		<label>Password</label>
		<input class="form-control" type="password" name="password">
	</div>
	<button type="submit" class="btn btn-primary" name="enter">enter</button>
</form>