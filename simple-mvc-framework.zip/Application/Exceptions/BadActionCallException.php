<?php
namespace Application\Exceptions;
class BadActionCallException extends \Exception{
	
}

?>