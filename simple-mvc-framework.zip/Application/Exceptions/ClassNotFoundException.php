<?php
namespace Application\Exceptions;
class ClassNotFoundException extends \Exception{
	
}

?>