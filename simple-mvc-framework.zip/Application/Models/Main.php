<?php
namespace Application\Models;

use Application\Core\Model;

class Main extends Model{
	
	public function __construct(){
		parent::__construct();
	} 
	
}

?>