<?php
namespace Application\Controllers;

use Application\Core\AbstractController;

class NewsController extends AbstractController{
	public function actionShow(){
		//
	}
}
?>