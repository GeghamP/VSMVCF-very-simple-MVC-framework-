<?php
//install and set xdebug
//for production make e_reporting E_ALL in php.ini and display_errors Off
//instead set log_errors On and specify a logging file path for error_log directive of php.ini 

?>