<?php
//access control list
return [
	"all"=>[
		"index"
	],
	"authorized"=> [
		//
	],
	"guest"=> [
		//
	],
	"admin"=> [
		//
	],
];

?>